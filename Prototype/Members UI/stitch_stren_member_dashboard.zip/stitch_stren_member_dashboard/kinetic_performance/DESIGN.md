---
name: Kinetic Performance
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#1e2024'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#bccaba'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#869486'
  outline-variant: '#3d4a3e'
  surface-tint: '#55e07f'
  primary: '#90ffa8'
  on-primary: '#003917'
  primary-container: '#5be584'
  on-primary-container: '#00642d'
  inverse-primary: '#006d32'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#ffe3c7'
  on-tertiary: '#472a00'
  tertiary-container: '#ffc072'
  on-tertiary-container: '#7a4c00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#74fd99'
  primary-fixed-dim: '#55e07f'
  on-primary-fixed: '#00210b'
  on-primary-fixed-variant: '#005224'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#111318'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  stat-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The visual identity targets high-performance athletes, boutique gym operators, and dedicated fitness enthusiasts who value data integrity, focus, and modern precision. The design evokes feelings of athletic discipline, focus, technical authority, and understated luxury.

Drawing inspiration from high-end analytical software (Linear) and polished fitness ecosystems (Apple Fitness), the interface adopts a **Modern Dark Minimalist** design movement infused with controlled tactile glows. 

The experience avoids loud distractions or decorative clutter. The deep, obsidian foundation recedes into the background to allow vital metrics, workout cadences, and schedule cards to emerge with crisp, surgical clarity. Neon mint accents serve as functional signals for achievement, activity, and high-priority actions.

## Colors

The color system is calibrated for deep dark mode environments, optimizing visual endurance and contrast across prolonged desktop usage.

### Hierarchy & Functional Roles
- **Canvas Base (`#090B0F`)**: Deepest background canvas for primary application windows and page scaffolding.
- **Surface Elevation (`#13171D`)**: Standard background for structural sidebars, navigation bars, and root parent cards.
- **Surface Container (`#1A1F26`)**: Elevated background for nested content modules, active tabs, hover states, and segmented data blocks.
- **Surface Highlight (`#222933`)**: Structural stroke color used across borders, grid dividers, and disabled interactive perimeters.
- **Primary Accent (`#5BE584`)**: High-visibility energetic neon mint. Reserved for primary calls-to-action, success states, progression milestones, active indicators, and critical metrics.
- **Secondary Accent (`#38BDF8`)**: Electric sky blue used for secondary trends, heart-rate zones, and hydration/aerobic tracking.
- **Tertiary Accent (`#F59E0B`)**: Amber gold applied exclusively for warnings, scheduling conflicts, streak alerts, and recovery load indicators.

### Text Contrast
- **Text Primary (`#F1F5F9`)**: Crisp slate-white for headlines, numeric figures, and primary labels.
- **Text Secondary (`#94A3B8`)**: Neutral blue-grey for secondary body copy, table values, and meta descriptions.
- **Text Muted (`#64748B`)**: Low-contrast tone for passive units of measure, timestamps, and placeholder copy.

## Typography

Typography relies on **Plus Jakarta Sans** for its geometric balance, crisp legibility at small sizes, and contemporary voice.

### Technical Implementation & Numeric Discipline
- **Tabular Figures**: All dashboard metrics, weight values, timers, reps, and dates must utilize `font-feature-settings: "tnum" 1` or `font-variant-numeric: tabular-nums` to prevent horizontal layout shift during live status updates.
- **Labels & Microcopy**: `label-sm` applies uppercase styling with `+0.04em` tracking for metadata, status indicators, and column table headers.
- **Visual Weight Pairing**: High-contrast pairings (e.g., `stat-display` in 700 weight paired with `label-sm` in 600 weight muted text) guarantee instant scanability for data dashboards.

## Layout & Spacing

The architecture operates on a **Desktop-First 12-Column Fluid Grid** structured within a fixed-width shell or persistent-sidebar frame.

### Core Shell Layout
- **Fixed Sidebar**: 260px fixed width docked on the left, running full viewport height. Collapsible to 72px icon-only state on smaller laptop viewports.
- **Top Header Bar**: 68px fixed height adhering to the upper viewport edge, featuring subtle glassmorphic backdrop filters, active global date selector, facility status indicators, and profile flyouts.
- **Main Viewport Canvas**: Fluid grid anchored by `2rem` (`margin`) outer padding, housing metric overview ribbons, schedule calendars, and performance analytics.

### Breakpoints & Adaptive Rules
- **Desktop Wide (≥1440px)**: Full 12-column structure; 24px (`gutter`) between dashboard cards. Multi-metric summary bars split into 4 equal cards (col-3 each).
- **Desktop Standard (1024px – 1439px)**: 12-column structure; 20px gutters; sidebar collapses if viewport width drops under 1200px. Overview panels re-balance into a 2x2 grid.
- **Tablet / Laptop Compact (768px – 1023px)**: 8-column layout; secondary analytics panes stack beneath prime attendance and workout charts.

## Elevation & Depth

Visual hierarchy uses a refined combination of **tonal surface stacking**, **low-contrast linear strokes**, and **directional ambient glows**. Heavy, muddy drop shadows are prohibited.

### Tonal Tiers
1. **Base Layer (0dp)**: `#090B0F` — Root canvas.
2. **Elevated Surfaces (1dp)**: `#13171D` with a subtle 1px border of `#222933`. Used for persistent sidebars, top headers, and default dashboard tiles.
3. **Interactive & Floating Containers (2dp)**: `#1A1F26` with 1px border of `#222933`. Used for dropdown menus, tooltips, modal sheets, and cards upon hover.

### Shadow & Glow Physics
- **Standard Card Rest**: `box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.45);`
- **Elevated Hover State**: `box-shadow: 0 12px 32px -4px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(91, 229, 132, 0.2);`
- **Accent Glow**: Used selectively behind active action buttons, progress completion rings, or high-tier member badges: `box-shadow: 0 0 24px rgba(91, 229, 132, 0.25);`
- **Linear Dividers**: Borders should use a single continuous 1px solid stroke in `#222933`. Under no circumstance should double-line strokes or thick bevels be rendered.

## Shapes

The design system standardizes on a modern, ergonomic geometric radius that balances structural SaaS reliability with sports hardware aesthetics:

- **Root Tiles & Dashboard Cards**: 14px to 16px radius (`rounded-lg` to `rounded-xl`), creating a smooth, framed containment for analytical charts and membership passes.
- **Controls & Input Elements**: 8px to 10px radius (`rounded`), providing sufficient curvature to feel modern without sacrificing spatial efficiency.
- **Tags, Pills, & Badges**: Fully rounded circular caps (9999px) for status badges (e.g., "Active Membership", "Checked In").
- **Avatar & Progress Rings**: Strict circles (50% radius) surrounded by 2px clearance gaps.

## Components

### Buttons
- **Primary Button**: Solid vibrant mint (`#5BE584`) background with `#090B0F` dark text, bold weight (`600`), 10px radius, 40px height for desktop. On hover, background shifts to a brightened mint with a subtle `0 0 16px rgba(91, 229, 132, 0.35)` glow.
- **Secondary Button**: Surface container (`#1A1F26`) background, 1px border in `#222933`, `#F1F5F9` text. Hover prompts border transition to `#94A3B8` and subtle background brightening.
- **Ghost / Destructive**: Transparent background with hover fill to `rgba(239, 68, 68, 0.1)` and text `#EF4444`.

### Cards & Analytical Tiles
- Built with a `#13171D` background and an external 1px border of `#222933`.
- Internal card padding standardizes to `1.5rem` (`space-lg`).
- Cards host a subtle top specular highlight gradient (`background: linear-gradient(180deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0) 100%)`).

### Input Fields & Controls
- **Text Inputs**: Height of 40px, background `#090B0F`, 1px border `#222933`, text `#F1F5F9`, placeholder `#64748B`.
- **Focus State**: Replaces border with `#5BE584` and casts a crisp `0 0 0 3px rgba(91, 229, 132, 0.15)` focus ring.
- **Checkboxes & Radios**: Custom square/circle controls with a `#1A1F26` fill, `#222933` outline. Checked states fill solid `#5BE584` with black check icon.

### Chips & Status Badges
- 24px height, fully pill-shaped.
- **Active / Positive Status**: Background `rgba(91, 229, 132, 0.12)`, text `#5BE584`, with a pulsing 6px solid dot inside the chip.
- **Passive / Category Chip**: Background `#1A1F26`, text `#94A3B8`, border 1px `#222933`.

### Data Lists & Tables
- Table header row uses uppercase `label-sm` with `#64748B` text and bottom border `#222933`.
- Rows feature alternating or clean unified `#13171D` surfaces with hover transition to `#1A1F26`.
- Metric numbers are always right-aligned using tabular figures; user identification and member status remain left-aligned.

### Domain-Specific Components
- **Heart Rate & Capacity Ring**: SVG circle metric featuring a track background of `#1A1F26` and an animated fill stroke of `#5BE584` or `#38BDF8` with rounded caps.
- **Class Booking & Schedule Pill**: Compact calendar card displaying start time, instructor thumbnail, training category indicator stripe, and instant "Book" / "Check-in" micro-interactions.