---
name: Kinetic Obsidian
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#1e2024'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#bccaba'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#869486'
  outline-variant: '#3d4a3e'
  surface-tint: '#55e07f'
  primary: '#90ffa8'
  on-primary: '#003917'
  primary-container: '#5be584'
  on-primary-container: '#00642d'
  inverse-primary: '#006d32'
  secondary: '#c3c6cf'
  on-secondary: '#2d3137'
  secondary-container: '#43474e'
  on-secondary-container: '#b2b5bd'
  tertiary: '#ceebff'
  on-tertiary: '#00354a'
  tertiary-container: '#89d4ff'
  on-tertiary-container: '#005c7e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#74fd99'
  primary-fixed-dim: '#55e07f'
  on-primary-fixed: '#00210b'
  on-primary-fixed-variant: '#005224'
  secondary-fixed: '#dfe2eb'
  secondary-fixed-dim: '#c3c6cf'
  on-secondary-fixed: '#181c22'
  on-secondary-fixed-variant: '#43474e'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#111318'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  metric-val:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-performance fitness technology: precise, powerful, and uncompromisingly modern. Designed for gym proprietors, elite coaches, and athletes, the interface strips away unnecessary decoration in favor of tactical clarity, functional density, and calibrated kinetic energy.

The aesthetic fuses **Modern Technical Minimalism** with **Dark Surface Architecture**. It draws direct inspiration from high-grade engineering tools and premium consumer hardware: deep obsidian canvases, razor-sharp typographic hierarchy, high-contrast legibility, and targeted emissions of vibrant neon mint. 

The emotional response is one of controlled intensity, discipline, and computational mastery. Micro-interactions should feel immediate and crisp (sub-150ms transitions), communicating responsiveness and operational excellence without sluggish theatrics.

## Colors

The palette operates under an intense dark-mode default, establishing an immersive viewport that focuses optical attention on performance metrics and dynamic activity states.

### Core Roles
- **Primary (`#5BE584`)**: Kinetic Mint. Reserved strictly for forward-momentum states, active metrics, confirmed attendance, primary actions, and critical status highlights. It carries an intentional fluorescent resonance.
- **Secondary (`#13171D`)**: Surface Card. The primary structural elevation above the void canvas, delivering tonal containment for complex dashboards and schedules.
- **Tertiary (`#38BDF8`)**: Electric Cyan. Used sparingly for secondary analytics, coach telemetry, and differential tracking metrics across comparative graphs.
- **Neutral / Canvas (`#090B0F`)**: Deep Obsidian. The absolute floor of the application, absorbing ambient distractions and giving luminous elements profound depth.

### Structural Neutrals & Text Hierarchy
- **Canvas Base**: `#090B0F`
- **Surface Elevation 1**: `#13171D`
- **Surface Elevation 2 (Containers & Active Items)**: `#1E242D`
- **Subtle Stroke / Dividers**: `#28323E`
- **Optical Inset Stroke**: `rgba(255, 255, 255, 0.08)`
- **Text High-Emphasis**: `#FFFFFF` (Headings, primary figures, active states)
- **Text Medium-Emphasis**: `#94A3B8` (Body copy, table labels, supporting copy)
- **Text Low-Emphasis**: `#64748B` (Timestamps, metadata, placeholders, inactive icons)

## Typography

The typographic engine uses a dual-family strategy calibrated for analytical rigor and athletic drive:

1. **Plus Jakarta Sans (Display & Headings)**: Provides a sharp, geometric structure with distinct grotesque characteristics that lend authority and modernity to dashboard headers, telemetry numbers, and section titles.
2. **Inter (Body, Tables, & Utility)**: Delivers peerless legibility at small sizes, optimal vertical metrics for dense workout plans and financial ledgers, and neutral functional beauty.

### Numeric Readouts & Data
All telemetry counters, repetition totals, time codes, and revenue numbers must employ tabular figures (`font-feature-settings: 'tnum' on, 'cv05' on`) to eliminate jitter during real-time updates and maintain rigid vertical alignment across tabular schedules.

## Layout & Spacing

The layout is built upon an 8-point geometric scale, enforcing dense information architecture without claustrophobia.

### Grid Foundations
- **Desktop (1200px+)**: 12-column dynamic fluid grid. Gutters locked at `1.5rem` (24px) with minimum outer canvas margins of `2rem` (32px). Maximum container width clamps at `1440px` for wide-screen control centers.
- **Tablet (768px - 1199px)**: 8-column layout. Gutters scale to `1rem` (16px), margins at `1.5rem` (24px). Sidebars collapse to icon-only rails.
- **Mobile (< 768px)**: 4-column stack. Gutters and outer margins set to `1rem` (16px). Bottom sheets and sticky action docks replace floating split-panes.

### Spacing Philosophy
Interfaces must be spaced by content grouping rather than arbitrary padding. Related metrics sit tightly unified (`space-xs` to `space-sm`), bounded by structural cards that absorb wide separation (`space-md` to `space-lg`), giving charts and lists breathing room.

## Elevation & Depth

In this dark-mode paradigm, visual depth is achieved not through drop shadows—which disappear on near-black surfaces—but through **tonal stratification**, **luminescent edging**, and **diffused ambient backlights**.

### Elevation Tiers
1. **Tier 0 (The Floor - `#090B0F`)**: Canvas background, root viewport, inactive gutter spaces.
2. **Tier 1 (Surface Baseline - `#13171D`)**: Standard cards, table containers, calendar blocks. Outlined with a continuous 1px stroke of `#28323E`.
3. **Tier 2 (Surface Floating - `#1E242D`)**: Dropdown menus, modal sheets, hover states of Tier 1 cards, tooltips. Enhanced with a hairline inner rim: `box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.08)`.
4. **Tier 3 (Active Popovers & Sheets)**: Inset hairline combined with ambient dark diffusion: `box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.7), inset 0 1px 0 0 rgba(255, 255, 255, 0.12)`.

### Luminescent Glows
Interactive triggers in active states emit focused, diffused energy. Neon mint glows are achieved with restrained dual shadows:
- `box-shadow: 0 0 0 1px #5BE584, 0 0 20px -4px rgba(91, 229, 132, 0.35)`
This highlights presence without leaking ambient mud across the interface.

## Shapes

The design system employs a refined curvature scale (`roundedness: 2`) that balances technical precision with modern ergonomic softness.

- **Primary Cards & Modals**: `rounded-xl` (12px to 16px) creates a polished frame for metrics without wasting inner corner space.
- **Action Elements & Inputs**: Standardized at 8px to 10px (`rounded-md` / `rounded-lg`) to preserve crisp mechanical affordance.
- **Pills & Status Micro-Badges**: Fully rounded (`9999px`) for member presence tags, capacity counts, and tier pills.
- **Dividers & Focus Rings**: 1px structural lines; never 2px unless actively focused by keyboard navigation.

## Components

### Buttons
- **Primary Action**: Solid `#5BE584` fill with `#090B0F` high-contrast typography (Inter SemiBold). Subtly glows on hover with `rgba(91, 229, 132, 0.25)`. Transitions occur across 120ms ease-out.
- **Secondary / Surface Action**: Background `#1E242D` with subtle border `#28323E` and white text. Hover triggers `background-color: #28323E` and brings the inner white rim to life.
- **Ghost Action**: Transparent background, text `#94A3B8`. Hover transitions text to `#FFFFFF` with `background: rgba(255, 255, 255, 0.04)`.

### Inputs & Controls
- **Text Inputs**: Height 40px, filled with `#090B0F`, bordered by `#28323E`. On focus: dynamic border transition to `#5BE584` accompanied by an inner stroke ring `ring-1 ring-[#5BE584]/30`.
- **Checkboxes & Radios**: 18px square/circle with `#13171D` body and `#28323E` border. When checked, surface transforms to solid `#5BE584` with a stark black checkmark glyph.

### Cards & Telemetry Blocks
- **Stat Metric Cards**: Encased in `#13171D`, bounded by `#28323E`. Header contains `label-md` in `#94A3B8`, center holds massive numeric figures in `Plus Jakarta Sans`, and footer houses trend indicators featuring green/red indicators with low-opacity pill surrounds (`rgba(91, 229, 132, 0.1)`).

### Chips & Badges
- **Status Chips**: Compact heights (24px), text in `label-sm`. Built using low-opacity color flood: member active states sit on `rgba(91, 229, 132, 0.1)` with `#5BE584` text; at-risk members utilize `rgba(239, 68, 68, 0.1)` with `#EF4444` text. Include a 6px solid pulsing dot for real-time gym check-ins.

### Specialized Domain Components
- **Capacity Meter**: Real-time occupancy gauge utilizing stacked horizontal bars with segmented markers, stepping from `#5BE584` to amber and neon crimson as occupancy approaches maximum gym fire codes.
- **Class Timeline Rail**: Vertical schedule tracker displaying coach avatars, active floor space, and live session timers using glowing accent rules.