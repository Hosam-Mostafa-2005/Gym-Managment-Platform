---
name: Kinetic Obsidian
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#1e2024'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#bccaba'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#869486'
  outline-variant: '#3d4a3e'
  surface-tint: '#55e07f'
  primary: '#90ffa8'
  on-primary: '#003917'
  primary-container: '#5be584'
  on-primary-container: '#00642d'
  inverse-primary: '#006d32'
  secondary: '#48d7f9'
  on-secondary: '#003641'
  secondary-container: '#01b8d9'
  on-secondary-container: '#004451'
  tertiary: '#ffe3c2'
  on-tertiary: '#452b00'
  tertiary-container: '#ffc065'
  on-tertiary-container: '#764d00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#74fd99'
  primary-fixed-dim: '#55e07f'
  on-primary-fixed: '#00210b'
  on-primary-fixed-variant: '#005224'
  secondary-fixed: '#afecff'
  secondary-fixed-dim: '#48d7f9'
  on-secondary-fixed: '#001f27'
  on-secondary-fixed-variant: '#004e5d'
  tertiary-fixed: '#ffddb3'
  tertiary-fixed-dim: '#ffb950'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#111318'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 12px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-xxl: 2rem
---

## Brand & Style

This design system embodies high-performance athletic intelligence. Built for elite strength coaches, performance directors, and gym enterprise operators, the interface merges the rigorous, low-latency ergonomics of developer-first platforms with the focused intensity of biomechanical tracking. 

The aesthetic is precision-driven dark mode minimalism infused with sharp structural lines, subtle glass depth, and targeted energetic accents. It deliberately avoids generic dashboard bloat in favor of extreme data density, instant visual scanning, and tactile feedback. Every interaction conveys mechanical accuracy, operational command, and frictionless execution.

## Colors

The palette relies on deep, obsidian-grade neutrals anchored by high-visibility functional cues. 

- **Primary Canvas & Surfaces:** Background base sits at `#090B0F`. Structural containers layer upward through Base Surface (`#13171D`) to Elevated Surface (`#1A1F26`). High-interaction active states and flyouts rest at `#222832`.
- **Borders & Dividers:** Single-pixel structural seams use `#222832` at resting state, transitioning to `rgba(255, 255, 255, 0.12)` on active hover states.
- **Accents:** 
  - Kinetic Accent (Primary): Vibrant neon green (`#5BE584`) reserved for primary action points, completed telemetry, and vital targets.
  - Telemetry Cyan (Secondary): `#00B8D9` for analytics overlays, physiological metrics, and data streams.
  - Performance Amber (Tertiary): `#FFAB00` for load fatigue warnings, pending check-ins, and schedule conflicts.
  - Critical Alert: `#FF5630` for heart rate anomalies, missed benchmarks, and overdue account escalations.
- **Text & Contrast:** Primary text (`#F4F6F8`) provides razor-sharp readability without harsh glare. Secondary text (`#919EAB`) supports metadata and column labels. Muted text (`#637381`) isolates inactive states, keyboard shortcuts, and structural timestamps.

## Typography

The type hierarchy couples the neutral geometric precision of `Geist` with the structured data fidelity of `JetBrains Mono`. 

- **Primary Interfaces (`Geist`):** Delivers clean optical balance in dense information panes. Letter-spacing tightens slightly on larger headings to reinforce a locked-in, engineered feel.
- **Data & Telemetry (`JetBrains Mono`):** Applied to tabular numbers, rep-max formulas, delta percentages, timestamps, and equipment IDs. Ensures uniform column alignment across real-time dynamic monitors without horizontal layout shifting.

## Layout & Spacing

The layout model is governed by a strict fluid 12-column grid designed for dense multi-pane coach monitoring.

- **Breakpoints:**
  - Mobile (`< 768px`): Collapsed 4-column stack. Sidebars fold into an absolute gesture drawer. Data tables revert to swipeable summary cards. Margins reduce to `1rem`.
  - Tablet (`768px – 1199px`): 8-column layout. Left navigation collapses to an icon rail (`56px`). Right telemetry pane docks beneath the primary session viewport.
  - Desktop (`≥ 1200px`): Full 12-column operational layout. Fixed persistent left command rail (`240px`), flexible main viewport (athlete rosters, program matrices), and optional dockable contextual panel (`360px`) for real-time biomechanics.
- **Rhythm:** Spacing embraces high information density. Component internal gaps rely primarily on `space-xs` (4px) and `space-sm` (8px). Structural section separation caps cleanly at `space-xl` (24px) to keep vital indicators within immediate viewport sightlines.

## Elevation & Depth

Visual hierarchy uses a refined layering system combining tonal surfaces, sub-pixel edge boundaries, and controlled ambient glow rather than dramatic drop shadows.

- **Base Floor (`#090B0F`):** Canvas background. Completely flat with no shadow.
- **Container Level 1 (`#13171D`):** Primary card modules, roster tables, chart containers. Bounded by a crisp 1px stroke of `#222832`.
- **Elevated Level 2 (`#1A1F26`):** Hovered cards, context tooltips, dropdown menus. Receives a faint structural shadow: `0 4px 20px -2px rgba(0, 0, 0, 0.65)` with a top edge inner-highlight (`box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.05)`).
- **Floating Modals & Flyouts (`#13171D` with Glass Blur):** Modals utilize a backdrop filter of `blur(12px)` supported by a 90% alpha surface fill (`rgba(19, 23, 29, 0.90)`). Shadow: `0 16px 36px -4px rgba(0, 0, 0, 0.85)`.
- **Kinetic Glow Accents:** When critical athlete metrics breach thresholds or when active timers engage, elements project a constrained, saturated neon blur (`0 0 12px rgba(91, 229, 132, 0.25)` or `0 0 12px rgba(255, 86, 48, 0.25)`), instantly directing coach focus without visual clutter.

## Shapes

The interface embraces a tight, technical corner philosophy (Soft / Level 1). 

- Standard inputs, buttons, athlete tags, and utility chips sit at `0.25rem` (4px) radius.
- Cards, sub-panels, and dashboard widgets carry an `8px` (`rounded-lg`) radius.
- System modals and large flyout panels use a maximum of `12px` (`rounded-xl`).
- Status dots and live session recording pings remain full circles (`rounded-full`).

This low-radius discipline prevents the interface from feeling playful or casual, reinforcing an engineered, tactical environment suited for clinical strength and conditioning data.

## Components

### Buttons
- **Primary:** Neon green background (`#5BE584`), deep black text (`#090B0F`), weight 600. Hover shifts to `#4cd174` with an instantaneous subtle box shadow (`0 0 10px rgba(91, 229, 132, 0.35)`).
- **Secondary:** Surface elevated (`#1A1F26`), border 1px solid `#222832`, text `#F4F6F8`. Hover: border shifts to `rgba(255, 255, 255, 0.2)`, background to `#222832`.
- **Ghost/Tertiary:** Transparent fill, text `#919EAB`. Hover: background `#1A1F26`, text `#F4F6F8`.
- **Destructive:** Border `rgba(255, 86, 48, 0.3)`, text `#FF5630`, subtle hover glow.

### Form Inputs & Selectors
- **Text Inputs:** Height 36px, background `#0D1015`, border 1px solid `#222832`, radius 4px. Text `#F4F6F8`, placeholder `#637381`.
- **Focus State:** Border shifts cleanly to `#5BE584` with an outer ring glow of `0 0 0 1px #5BE584`.
- **Monospace Numerical Steppers:** Embedded quick-increment buttons for micro-adjusting weights (kg/lbs) and repetition counts, featuring right-aligned `JetBrains Mono` figures.

### Chips & Badges
- **Status Badges:** Height 20px, font `JetBrains Mono` (10px), uppercase, letter-spacing 0.04em.
- **Variants:**
  - Active / In-Zone: Background `rgba(91, 229, 132, 0.12)`, text `#5BE584`, border 1px solid `rgba(91, 229, 132, 0.25)`.
  - Strained / Warning: Background `rgba(255, 171, 0, 0.12)`, text `#FFAB00`, border 1px solid `rgba(255, 171, 0, 0.25)`.
  - Critical / Overload: Background `rgba(255, 86, 48, 0.12)`, text `#FF5630`, border 1px solid `rgba(255, 86, 48, 0.25)`.

### Cards & Telemetry Tiles
- **Structure:** Background `#13171D`, border 1px solid `#222832`, padding 16px.
- **Card Header:** Subdued 11px uppercase label font (`#919EAB`) with right-aligned status indicator or delta trend arrow.
- **Interactive State:** Border color scales to `rgba(255, 255, 255, 0.15)` on cursor entry; subtle elevation bump without shifting element geometry.

### Lists & Data Tables
- **Table Density:** Compact row height (40px). Striping is omitted; rows separate via horizontal 1px line of `#1A1F26`.
- **Header:** Sticky header, background `#090B0F`, text `#637381`, font `JetBrains Mono` (11px), uppercase.
- **Row Hover:** Surface transforms to `#1A1F26` across all cells with a 150ms ease transition.

### Checkboxes & Switches
- **Checkboxes:** 16x16px, background `#13171D`, border 1px solid `#637381`, radius 3px. Checked state: `#5BE584` fill with dark check icon.
- **Switches:** 32x18px pill enclosure. Off state `#222832`, active state `#5BE584`. Thumb is a 14px solid white circular knob with smooth mechanical transition (120ms cubic-bezier).

### Specialized Command Center Modules
- **Athlete Vitals Ribbon:** Ultra-condensed horizontal strip displaying live heart rate, velocity loss %, and target RPE with mini sparkline graphs.
- **Command Palette (`Cmd + K`):** Floating overlay with frosted backdrop (`rgba(9, 11, 15, 0.8)`), dedicated instantaneous search input, and categorical shortcuts for fast athlete lookup, workout assignment, and gym rack reassignment.